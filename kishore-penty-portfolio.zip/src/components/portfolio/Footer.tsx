'use client'

import { Terminal, Heart } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-border py-8 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Terminal className="w-3.5 h-3.5 text-primary" />
            <span className="font-mono">
              kishore<span className="text-primary">@</span>devops
            </span>
          </div>
          <p className="text-xs text-muted-foreground/70 flex items-center gap-1">
            Built with <Heart className="w-3 h-3 text-primary fill-primary" /> using Next.js & Tailwind CSS
          </p>
          <p className="text-xs text-muted-foreground/70">
            &copy; {new Date().getFullYear()} Kishore Penty. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}