'use client'

import { motion } from 'framer-motion'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Terminal,
  ChevronDown,
  Mail,
  Phone,
  Download,
} from 'lucide-react'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden grid-pattern">
      {/* Gradient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-primary/3 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        {/* Terminal badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 mb-8"
        >
          <Badge
            variant="outline"
            className="px-4 py-1.5 font-mono text-xs border-primary/30 bg-primary/5 text-primary"
          >
            <Terminal className="w-3 h-3 mr-1.5" />
            kishore@devops:~$ <span className="animate-blink ml-1">_</span>
          </Badge>
        </motion.div>

        {/* Name */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight mb-4"
        >
          Kishore{' '}
          <span className="text-primary">Penty</span>
        </motion.h1>

        {/* Title */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-lg sm:text-xl md:text-2xl text-muted-foreground font-medium mb-3"
        >
          AWS Platform Engineer | Senior Cloud & DevOps Engineer
        </motion.p>

        {/* Location */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.25 }}
          className="text-sm text-muted-foreground/70 font-mono mb-8"
        >
          Hyderabad, India
        </motion.p>

        {/* Summary */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-10"
        >
          Results-driven AWS Platform Engineer with <strong className="text-foreground">9+ years</strong> of experience
          in Infrastructure Development, AWS Cloud Architecture, and DevOps Engineering. Proficient in multi-account
          Landing Zones, IaC with Terraform & CloudFormation, and CI/CD automation with Jenkins & GitHub Actions.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-3 justify-center items-center"
        >
          <a href="#experience">
            <Button size="lg" className="gap-2 min-w-[180px]">
              <Terminal className="w-4 h-4" />
              View Experience
            </Button>
          </a>
          <a href="mailto:pkishore9391@gmail.com">
            <Button variant="outline" size="lg" className="gap-2 min-w-[180px]">
              <Mail className="w-4 h-4" />
              Get in Touch
            </Button>
          </a>
        </motion.div>

        {/* Quick stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="flex flex-wrap justify-center gap-6 sm:gap-10 mt-16"
        >
          {[
            { value: '9+', label: 'Years Experience' },
            { value: '100+', label: 'AWS Accounts Managed' },
            { value: '4', label: 'Cloud Certifications' },
            { value: '3', label: 'Cloud Platforms' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-primary font-mono">
                {stat.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <ChevronDown className="w-5 h-5 text-muted-foreground/50" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}