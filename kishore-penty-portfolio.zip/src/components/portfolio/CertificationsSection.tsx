'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Award,
  Trophy,
} from 'lucide-react'

const certifications = [
  { title: 'AWS Certified Solutions Architect – Associate', issuer: 'Amazon Web Services', icon: 'AWS' },
  { title: 'GitHub Actions Certification', issuer: 'GitHub (2016)', icon: 'GH' },
  { title: 'GCP Associate Cloud Engineer', issuer: 'Google Cloud Platform', icon: 'GCP' },
  { title: 'Microsoft Certified: Azure Administrator Associate', issuer: 'Microsoft', icon: 'AZ' },
]

const awards = [
  { title: 'Excellence Award', description: 'Outstanding contribution to delivery of project demands' },
  { title: 'TechnoWiz Award', description: 'Recognition for contribution of innovative Proof of Concepts (PoCs)' },
]

function AnimatedCard({ children, index }: { children: React.ReactNode; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-30px' })
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.4, delay: index * 0.1 }}
    >
      {children}
    </motion.div>
  )
}

export function CertificationsSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <section id="certifications" className="py-20 sm:py-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <Badge variant="outline" className="mb-4 font-mono text-xs border-primary/30 text-primary">
            {'<certifications>'}
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold">Certifications & Awards</h2>
          <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
            Multi-cloud certified professional with recognition for innovation and excellence.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
          {certifications.map((cert, i) => (
            <AnimatedCard key={cert.title} index={i}>
              <Card className="border-border/50 hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 group h-full">
                <CardContent className="p-5 flex items-start gap-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 shrink-0 group-hover:bg-primary/20 transition-colors">
                    <span className="text-primary font-mono font-bold text-sm">{cert.icon}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm leading-snug">{cert.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{cert.issuer}</p>
                  </div>
                </CardContent>
              </Card>
            </AnimatedCard>
          ))}
        </div>

        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-primary" />
          Awards & Recognition
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {awards.map((award, i) => (
            <AnimatedCard key={award.title} index={i}>
              <Card className="border-border/50 hover:border-primary/30 transition-all duration-300 h-full">
                <CardContent className="p-5 flex items-start gap-3">
                  <Award className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h4 className="font-semibold text-sm">{award.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{award.description}</p>
                  </div>
                </CardContent>
              </Card>
            </AnimatedCard>
          ))}
        </div>
      </div>
    </section>
  )
}