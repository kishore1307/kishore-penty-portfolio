'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Briefcase,
  Calendar,
  MapPin,
  ChevronRight,
} from 'lucide-react'

interface Experience {
  company: string
  role: string
  location: string
  period: string
  highlights: string[]
}

const experiences: Experience[] = [
  {
    company: 'NTT DATA',
    role: 'AWS Platform Engineer',
    location: 'Hyderabad',
    period: 'August 2025 – Present',
    highlights: [
      'Leveraged GitHub Copilot to accelerate Terraform code development, generate HCL configurations, and troubleshoot plan/apply errors — improving development velocity and code quality.',
      'Utilised Amazon Q Business to query internal documentation, cloud governance policies, and AWS best practices, enabling faster decision-making.',
      'Authored and maintained reusable Terraform modules for VPC, baseline account configuration, Security Hub enrolment, hosted zones, and IDP role provisioning across Landing Zones.',
      'Managed and customised 100+ AWS accounts across multi-account Landing Zones using Terraform (IaC), ensuring compliance with enterprise cloud governance standards.',
      'Provisioned VPCs, subnets, NACLs, security groups, and Transit Gateway configurations across multiple AWS regions.',
      'Designed IAM roles, OIDC providers, and role assignments to enable secure CI/CD pipelines and least-privilege access.',
      'Integrated OPA/Checkov policy checks and Wiz security scanning into CI/CD pipelines for automated Terraform plan validation.',
      'Built CIDR conflict detection workflows to automate network validation and prevent IP range overlaps.',
    ],
  },
  {
    company: 'Hitachi Vantara',
    role: 'Senior DevOps Engineer',
    location: 'Hyderabad',
    period: 'June 2022 – August 2025',
    highlights: [
      'Proficient in writing Infrastructure as Code using HashiCorp Terraform (HCL) and deploying automation scripts in Python using Lambda.',
      'Configured Elastic Load Balancer and Auto Scaling for high availability; SSL certificates via Amazon Certificate Manager.',
      'Managed AWS S3 for object storage, ACL, lifecycle management, static website hosting, and replication.',
      'Hands-on with AWS RDS (MySQL, Aurora DB, MariaDB), custom VPC setup, subnets, route tables, and VPC Peering.',
      'Managed IAM roles, policies, permission boundaries, Stack Sets, SCPs, and KMS key creation.',
      'Deployed AWS HSM Cluster, created Custom Key Store, and provisioned AMIs backed by HSM/KMS keys.',
      'Integrated AWS Bedrock with Service Catalog for GenAI applications via governed self-service provisioning workflows.',
      'Debugged real-time pod issues across Prod, UAT, and Dev environments in Kubernetes/EKS.',
      'Administered Jenkins CI/CD pipelines and integrated Grafana/Prometheus for monitoring.',
    ],
  },
  {
    company: 'Freestone Infotech Pvt Ltd.',
    role: 'Senior DevOps Engineer',
    location: 'Mumbai',
    period: 'February 2020 – June 2022',
    highlights: [
      'Deployed infrastructure on AWS using Terraform and Console; created Ansible Playbooks for web and application servers.',
      'Managed CI/CD pipelines using Jenkins, Maven, Ansible, Terraform, and Git for end-to-end delivery.',
      'Provided end-to-end AWS support: VPC, EC2, S3, RDS, ELB, Auto Scaling, CloudWatch, CloudFront, Route 53, NACL, Security Groups, WAF.',
      'Implemented ELK stack — deployed Elasticsearch clusters; configured Kibana and Logstash for log monitoring and Metricbeat.',
      'Automated AWS tasks using Python scripts; configured SSL certificates via ACM and third-party DNS providers.',
      'Integrated HashiCorp Vault with internal vault for password management across all environments.',
    ],
  },
  {
    company: 'Optum Global Solutions',
    role: 'Cloud Engineer / DevOps Engineer',
    location: 'Hyderabad',
    period: 'July 2017 – September 2019',
    highlights: [
      'Deployed and managed multi-tier, high-availability AWS infrastructure across production, staging, and development environments.',
      'Managed EC2, EBS, IAM, S3, ELB, Auto Scale, CloudWatch, VPC, CloudFront, NACL, and Security Groups.',
      'Set up Kubernetes clusters and managed pods; deployed Docker-based microservices to EKS and AKS from private registries.',
      'Performed Physical to Cloud Migration in AWS using CloudEndure.',
      'Configured SSL certificates on Elastic Load Balancer for HTTPS traffic.',
    ],
  },
  {
    company: 'Magna Infotech',
    role: 'Linux Admin / Cloud Admin / DevOps Engineer',
    location: 'Hyderabad',
    period: 'August 2016 – February 2017',
    highlights: [
      'Managed Red Hat Enterprise Linux-based infrastructure; administered user accounts, groups, directories, and file permissions.',
      'Installed Nagios for monitoring; installed Splunk Universal Forwarder and clusters on UNIX; configured Yum repository server.',
      'Performed disk management using LVM; configured Apache Web Server, SSL, and handled OS-level support on RHEL 5.x–7.x, AIX, HP-UX.',
      'Automated tasks using Python scripts; experience with BMC Remedy and ServiceNow for change management.',
    ],
  },
]

function ExperienceCard({ exp, index }: { exp: Experience; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -30 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="group relative overflow-hidden border-border/50 hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5">
        <div className="absolute top-0 left-0 w-1 h-full bg-primary/60 group-hover:bg-primary transition-colors" />
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-primary" />
                {exp.company}
              </CardTitle>
              <p className="text-primary font-medium mt-0.5">{exp.role}</p>
            </div>
            <div className="flex flex-col items-start sm:items-end gap-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {exp.period}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {exp.location}
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <ul className="space-y-2">
            {exp.highlights.map((h, i) => (
              <li key={i} className="flex gap-2 text-sm text-muted-foreground leading-relaxed">
                <ChevronRight className="w-3.5 h-3.5 text-primary/70 mt-1 shrink-0" />
                <span>{h}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export function ExperienceSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <section id="experience" className="py-20 sm:py-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <Badge variant="outline" className="mb-4 font-mono text-xs border-primary/30 text-primary">
            {'<experience>'}
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold">Work Experience</h2>
          <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
            9+ years of progressive experience in cloud infrastructure, DevOps engineering, and platform automation.
          </p>
        </motion.div>

        <div className="space-y-6">
          {experiences.map((exp, i) => (
            <ExperienceCard key={exp.company} exp={exp} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}