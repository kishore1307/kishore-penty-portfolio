'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Cloud,
  Code2,
  GitBranch,
  FileCode,
  Container,
  Database,
  Activity,
  Shield,
  GitFork,
  Layout,
  Server,
} from 'lucide-react'

interface SkillCategory {
  title: string
  icon: React.ElementType
  skills: string[]
}

const skillCategories: SkillCategory[] = [
  {
    title: 'Cloud Technologies',
    icon: Cloud,
    skills: ['AWS', 'Microsoft Azure', 'Google Cloud Platform (GCP)'],
  },
  {
    title: 'IaC & Automation',
    icon: FileCode,
    skills: ['Terraform', 'AWS CloudFormation', 'Ansible', 'AWS CDK'],
  },
  {
    title: 'CI/CD Tools',
    icon: GitBranch,
    skills: ['Jenkins', 'GitHub Actions', 'GitLab CI/CD', 'Maven', 'npm'],
  },
  {
    title: 'Scripting',
    icon: Code2,
    skills: ['Python', 'Bash Scripting', 'Groovy', 'AWS CLI'],
  },
  {
    title: 'Containerization',
    icon: Container,
    skills: ['Docker', 'Kubernetes (EKS, AKS)', 'ECS'],
  },
  {
    title: 'Databases',
    icon: Database,
    skills: ['MySQL', 'Aurora', 'MariaDB', 'DynamoDB', 'DocumentDB', 'Neptune DB', 'Redshift'],
  },
  {
    title: 'Monitoring',
    icon: Activity,
    skills: ['Grafana', 'Prometheus', 'DataDog', 'New Relic', 'Helm', 'CloudWatch', 'CloudTrail'],
  },
  {
    title: 'Security & Compliance',
    icon: Shield,
    skills: ['KMS', 'HSM', 'ACM', 'IAM', 'SCPs', 'OPA', 'Checkov', 'Wiz', 'AWS Security Hub'],
  },
  {
    title: 'Version Control',
    icon: GitFork,
    skills: ['Git', 'GitHub', 'Bitbucket', 'GitLab', 'SVN'],
  },
  {
    title: 'Bug Tracking',
    icon: Layout,
    skills: ['JIRA', 'Confluence'],
  },
  {
    title: 'Operating Systems',
    icon: Server,
    skills: ['RHEL/CentOS 5.x/6.x/7.x', 'Ubuntu', 'Linux'],
  },
  {
    title: 'Web & App Servers',
    icon: Layout,
    skills: ['Apache', 'Tomcat', 'Nginx'],
  },
]

function SkillCard({ category, index }: { category: SkillCategory; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-30px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      <Card className="h-full border-border/50 hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 group">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <category.icon className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
            {category.title}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-1.5">
            {category.skills.map((skill) => (
              <Badge
                key={skill}
                variant="secondary"
                className="text-xs font-normal px-2.5 py-0.5 hover:bg-primary/10 hover:text-primary transition-colors"
              >
                {skill}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export function SkillsSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <section id="skills" className="py-20 sm:py-28 bg-card/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <Badge variant="outline" className="mb-4 font-mono text-xs border-primary/30 text-primary">
            {'<skills>'}
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold">Technical Skills</h2>
          <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
            Comprehensive toolkit spanning cloud platforms, automation, containerization, security, and monitoring.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {skillCategories.map((cat, i) => (
            <SkillCard key={cat.title} category={cat} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}