import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/portfolio/ThemeProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Kishore Penty | AWS Platform Engineer & Senior DevOps Engineer",
  description:
    "Portfolio of Kishore Penty — Results-driven AWS Platform Engineer with 9+ years of experience in Infrastructure Development, AWS Cloud Architecture, and DevOps Engineering.",
  keywords: [
    "Kishore Penty",
    "AWS Platform Engineer",
    "DevOps Engineer",
    "Cloud Engineer",
    "Terraform",
    "Kubernetes",
    "CI/CD",
    "AWS",
    "Infrastructure as Code",
  ],
  authors: [{ name: "Kishore Penty" }],
  openGraph: {
    title: "Kishore Penty | AWS Platform Engineer",
    description:
      "9+ years in AWS Cloud Architecture, DevOps Engineering, and Infrastructure Development.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}